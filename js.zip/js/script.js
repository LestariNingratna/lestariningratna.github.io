$(document).ready(function(){
		

		//real time halaman dashboard.php
				setInterval(function() {
            		$('.load-input').load('load-input.php');
          							}, 100);

	

  });